﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="https://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Cống bê tông đúc sẵn Công ty Cổ phần Bê Tông Phương Bắc</title>

<meta name="keywords" content="Cống bê tông đúc sẵn" />

<meta name="description" content="CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC CHUYÊN SẢN XUẤT VÀ CUNG CẤP CÁC SẢN PHẨM CỐNG BÊ TÔNG ĐÚC SẴN, CỐNG HỘP, CỐNG TRÒN, CỐNG HỘP ĐÔI, HỐ GA, HỐ THU, HÀO, RÃNH BÊ TÔNG, TẤM TƯỜNG BÊ TÔNG" />

<base href="https://betongphuongbac.com/" target="_self" />

<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />

<link rel="icon" href="images/favicon/8446logo_bt.png">


<meta property="og:title" content="Cống bê tông đúc sẵn Công ty Cổ phần Bê Tông Phương Bắc">

<meta property="og:type" content="website">

<meta property="og:description" content="CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC CHUYÊN SẢN XUẤT VÀ CUNG CẤP CÁC SẢN PHẨM CỐNG BÊ TÔNG ĐÚC SẴN, CỐNG HỘP, CỐNG TRÒN, CỐNG HỘP ĐÔI, HỐ GA, HỐ THU, HÀO, RÃNH BÊ TÔNG, TẤM TƯỜNG BÊ TÔNG">

<meta property="og:image" content="http://betongphuongbac.com/images/favicon/8446logo_bt.png">

<meta property="og:site_name" content="Cống bê tông đúc sẵn Công ty Cổ phần Bê Tông Phương Bắc">

<meta property="og:url" content="https://betongphuongbac.com/index.php">



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<link href="https://fonts.googleapis.com/css?family=Oswald:400,500,600,700|Roboto+Condensed:400,400i,700&amp;subset=vietnamese" rel="stylesheet">



<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>



<link type="text/css" rel="stylesheet" href="css/normalize.css" />

<link type="text/css" rel="stylesheet" href="css/css/layout.css" />

<link type="text/css" rel="stylesheet" href="css/css/contact/contact.css" />

<link type="text/css" rel="stylesheet" href="css/css/news/news.css" />

<link type="text/css" rel="stylesheet" href="css/css/product/product.css" />

<script type="text/javascript" language="javascript" src="css/js/jquery.mobilemenu.js"></script>

<script type="text/javascript" language="javascript" src="css/js/application.js"></script>



<link type="text/css" rel="stylesheet" href="css/animate/animate.css" />

<script type="text/javascript" language="javascript" src="css/animate/wow.min.js"></script>



<link rel="stylesheet" href="css/css/owlcarousel/assets/owl.carousel.min.css">

<link rel="stylesheet" href="css/css/owlcarousel/assets/owl.theme.default.min.css">

<script src="css/css/owlcarousel/owl.carousel.js"></script>



<script type="text/javascript">

$(document).ready(function() {

	new WOW({

			offset:       10,

			mobile:       false

		}).init();

	$('.taskbar-m .btn-m').mobilemenu();

    var document_w = $(document).width();

    $('.body_bg .left ._box > p').click(function() {

    	if (document_w < 768) {

    		$(this).next().toggle('medium');

    	}

    });



    if (document_w > 992) {

    	$('.body_bg .right').css('min-height', $('.body_bg').height());

    }



	// Animate the scroll to top

	$('.go-top').click(function(event) {

		event.preventDefault();

		$('html, body').animate({scrollTop: 0}, 500);

	})



	$(window).scroll(function(){

		if (document_w < 992){

			$('.menu-m').css('top',$(this).scrollTop());

			if($('.wrapper ' ).hasClass( "wrapper-m" )==true){

				$('.taskbar-m').css({'top':$(this).scrollTop(),'position':'absolute'});

			}

			else{

				$('.taskbar-m').css({'top':0,'position':'fixed'});

			}

		}

	});



	$('.slide-carousel').owlCarousel({

        loop: true,

        autoplay:true,

        margin:0,

        responsiveClass:true,

        responsive:{

            0:{ items:1, nav:false, dots: true },

            600:{ items:1, nav:false, dots: true },

            1000:{ items:1, nav:false, dots: true }

        }

    });

    $('.partner-carousel').owlCarousel({

        loop: true,

        autoplay:true,

        margin:20,

        responsiveClass:true,

        responsive:{

            0:{ items:2, nav:false, dots: true },

            600:{ items:3, nav:false, dots: true },

            1000:{ items:6, nav:false, dots: true }

        }

    });

    $('.product-carousel').owlCarousel({

        loop: true,

        autoplay:true,

        margin:20,

        responsiveClass:true,

        responsive:{

            0:{ items:1, nav:false, dots: true },

            600:{ items:2, nav:false, dots: true },

            1000:{ items:3, nav:false, dots: true }

        }

    });

    $('.comment-carousel').owlCarousel({

        loop: true,

        autoplay:false,

        margin: 10,

        responsiveClass:true,

         nav:true,

        responsive:{

            0:{ items:1, nav:false, dots: true },

            600:{ items:1, nav:false, dots: true },

            1000:{ items:2, nav:true, dots: true }

        }

    });



});



</script>



</head>



<body>

	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PG4PM5L');</script>
<!-- End Google Tag Manager --><script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '{your-app-id}',
      cookie     : true,
      xfbml      : true,
      version    : '{api-version}'
    });
      
    FB.AppEvents.logPageView();   
      
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
	

	<!-- Begin wrapper -->

	<div class="wrapper animate">

		<!-- Begin menu-m -->
		<div class="menu-m">
							<ul>
											<li><a href="/">Trang chủ</a>
													</li>
												<li><a href="/gioi-thieu-a1.html">Giới thiệu</a>
							<span></span>								<ul class="one">
									<li><a href="/thong-tin-cong-ty-a6.html"><i class="fa fa-angle-right"></i> Thông tin công ty</a>
																				</li><li><a href="/chinh-sach-chat-luong--a5.html"><i class="fa fa-angle-right"></i> Chính sách chất lượng</a>
																				</li><li><a href="/nhan-luc-a4.html"><i class="fa fa-angle-right"></i> Năng lực công ty</a>
																				</li>								</ul>
														</li>
												<li><a href="/index.php/chung-nhan-tieu-chuan-san-pham-a9.html">Chứng nhận tiêu chuẩn sản phẩm</a>
													</li>
												<li><a href="/du-an-a3.html">Dự án</a>
													</li>
												<li><a href="#">Sản phẩm</a>
							<span></span>								<ul class="one">
									<li><a href="/cong-be-tong-c46.html"><i class="fa fa-angle-right"></i> CỐNG BÊ TÔNG</a>
										<span></span>											<ul class="two">
												<li><a href="/index.php/de-cong-%28goi-do-cong%29-c60.html"><i class="fa fa-angle-double-right"></i> ĐẾ CỐNG (GỐI ĐỠ CỐNG)</a></li><li><a href="/index.php/gioang-cao-su-c58.html"><i class="fa fa-angle-double-right"></i> GIOĂNG CAO SU</a></li><li><a href="/cong-tron-c53.html"><i class="fa fa-angle-double-right"></i> CỐNG TRÒN</a></li><li><a href="/cong-hop--c54.html"><i class="fa fa-angle-double-right"></i> CỐNG HỘP</a></li><li><a href="/cong-hop-doi-c55.html"><i class="fa fa-angle-double-right"></i> CỐNG HỘP ĐÔI</a></li>											</ul>
																					</li><li><a href="/ho-ga-duc-san-c48.html"><i class="fa fa-angle-right"></i> HỐ GA ĐÚC SẴN</a>
																				</li><li><a href="/index.php/cac-san-pham-khac-c51.html"><i class="fa fa-angle-right"></i> HÀO KỸ THUẬT, RÃNH BÊ TÔNG</a>
																				</li><li><a href="/index.php/cac-san-pham-cau-kien-be-tong-duc-san-c50.html"><i class="fa fa-angle-right"></i> BÓ VỈA BÊ TÔNG, GẠCH BLOCK BÊ TÔNG</a>
																				</li><li><a href="/index.php/coc-van-cu-be-tong-du-ung-luc-c59.html"><i class="fa fa-angle-right"></i> CỌC VÁN CỪ BÊ TÔNG DỰ ỨNG LỰC</a>
																				</li><li><a href="/tam-tuong-be-tong-acotec-c47.html"><i class="fa fa-angle-right"></i> TẤM TƯỜNG BÊ TÔNG ACOTEC</a>
																				</li><li><a href="/cau-thang-duc-san-c49.html"><i class="fa fa-angle-right"></i> CẦU THANG ĐÚC SẴN</a>
																				</li>								</ul>
														</li>
												<li><a href="/du-an-l7.html">Đối tác</a>
							<span></span>								<ul class="one">
									<li><a href="/khach-hang-l10.html"><i class="fa fa-angle-right"></i> Khách hàng</a>
																				</li><li><a href="/nha-cung-cap-l8.html"><i class="fa fa-angle-right"></i> Nhà cung cấp</a>
																				</li>								</ul>
														</li>
												<li><a href="/index.php/vi-deo--a10.html">Thư viện Video</a>
													</li>
												<li><a href="/tin-tuc-l2.html">Tin tức</a>
							<span></span>								<ul class="one">
									<li><a href="/index.php/tin-tuyen-dung--l5.html"><i class="fa fa-angle-right"></i> Chính sách</a>
																				</li><li><a href="/tin-tuc-l2.html"><i class="fa fa-angle-right"></i> Tin tức nội bộ</a>
																				</li><li><a href="/tin-tuc-l2.html"><i class="fa fa-angle-right"></i> Tin tức chuyên ngành</a>
																				</li>								</ul>
														</li>
												<li><a href="/lien-he.html">Liên hệ</a>
													</li>
										</ul>
						</div>
		<!-- End menu-m -->

		<!-- Begin taskbar-m -->
		<div class="task-absolute d-block d-md-none">
			<div class="container">
				<div class="taskbar-m">
					<span>
						<script>
		                    $(document).ready(function(){
		                        $(".btn-m").click(function(){
		                            $(".fa-reorder").toggle();
		                            $(".fa-times").toggle();
		                        });
		                    });
		                </script>
						<button type="button" class="btn-m" ></button>
						<i class="fa fa-reorder"></i>
						<i class="fa fa-times"></i>
					</span>
					<a class="logo" href="/index.php"><img src="images/contact/4174logo_bt.png" alt="CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC top" /></a>
					<form class="search_form" action="/index.php/tim-kiem.html" method="GET">					<input type="text" name="txtkeyword" placeholder="Từ khóa tìm kiếm..." autocomplete="off">
					<button type="submit"><i class="fa fa-search"></i></button>
					</form>
				</div>
				<div class="padding-m"></div>
			</div>

		</div>
		<!-- End taskbar-m -->

		<!-- Begin top_page -->

		<div class="top_page d-none d-md-block">

			<div class="container">

				<div class="row no-gutters">



					<div class="col-6 wow bounceInLeft">

						<p class="welcome">CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC</p>

					</div>



					<div class="col-6 right">

						<div class="row no-gutters">

							<div class="search">

								<form action="/index.php/tim-kiem.html" method="GET">
									<input type="text" name="txtkeyword" placeholder="Từ khóa tìm kiếm..." autocomplete="off">

									<button type="submit"><i class="fa fa-search"></i></button>

								</form>
							</div>



							<div class="">

								<div class="social">

									<a href="" target="_blank"><i class="fa fa-twitter"></i></a>

									<a href="https://www.facebook.com/phuongbac.betong" target="_blank"><i class="fa fa-facebook"></i></a>

									<a href="" target="_blank"><i class="fa fa-google-plus"></i></a>

								</div>

								<div class="lang d-none">
									
									<a>Ngôn ngữ: </a>
									<a href="/index.php/site/setLangAdmin/1"><img width="26" height="20" src="images/languages/5974vietnam.png" alt="Tiếng Việt" /></a>								</div>

							</div>

						</div>

					</div>

				</div>

			</div>

		</div>

		<!-- End top_page -->





		

		<!-- Begin header -->

		<div class="header d-none d-md-block">

			<div class="container">

				<div class="row">

					

					<div class="col-2 logo wow fadeInLeft"">

						<a href="/index.php"><img src="images/contact/4174logo_bt.png" alt="CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC" /></a>

					</div>



					<div class="col-10 wow bounceInDown">

						<div class="tag_header text-right">

							<span class="address">Thôn Tổ Hỏa - Xã Yên Mỹ, Tỉnh Hưng Yên - MSDN : 0900988752 cấp ngày 28/03/2016 tại Hưng Yên</span>

							<span class="email">betongphuongbac@gmail.com</span>

							<span class="hotline">0947881181</span>

						</div>

						<div class="menu text-right">

							
								<ul>

									<li><a href="/">Trang chủ</a>

										
										</li><li><a href="/gioi-thieu-a1.html">Giới thiệu <i class="fa fa-angle-down"></i></a>

										
											<ul>

																									<li>
													    													    <a href="/thong-tin-cong-ty-a6.html">Thông tin công ty													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/chinh-sach-chat-luong--a5.html">Chính sách chất lượng													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/nhan-luc-a4.html">Năng lực công ty													        													    </a>
													    
													    													    
													</li>
											</ul>

											
										</li><li><a href="/index.php/chung-nhan-tieu-chuan-san-pham-a9.html">Chứng nhận tiêu chuẩn sản phẩm</a>

										
										</li><li><a href="/du-an-a3.html">Dự án</a>

										
										</li><li><a href="#">Sản phẩm <i class="fa fa-angle-down"></i></a>

										
											<ul>

																									<li>
													    													    <a href="/cong-be-tong-c46.html">CỐNG BÊ TÔNG													        <i class="fa fa-chevron-right"></i>													    </a>
													    
													            													<ul>
        														        														<li>
        															        															<a href="/index.php/de-cong-%28goi-do-cong%29-c60.html">
        																ĐẾ CỐNG (GỐI ĐỠ CỐNG)        																        															</a>
        
        															        														</li>
        														        														<li>
        															        															<a href="/index.php/gioang-cao-su-c58.html">
        																GIOĂNG CAO SU        																        															</a>
        
        															        														</li>
        														        														<li>
        															        															<a href="/cong-tron-c53.html">
        																CỐNG TRÒN        																        															</a>
        
        															        														</li>
        														        														<li>
        															        															<a href="/cong-hop--c54.html">
        																CỐNG HỘP        																        															</a>
        
        															        														</li>
        														        														<li>
        															        															<a href="/cong-hop-doi-c55.html">
        																CỐNG HỘP ĐÔI        																        															</a>
        
        															        														</li>
        														        													</ul>
        																									    
													</li>													<li>
													    													    <a href="/ho-ga-duc-san-c48.html">HỐ GA ĐÚC SẴN													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/index.php/cac-san-pham-khac-c51.html">HÀO KỸ THUẬT, RÃNH BÊ TÔNG													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/index.php/cac-san-pham-cau-kien-be-tong-duc-san-c50.html">BÓ VỈA BÊ TÔNG, GẠCH BLOCK BÊ TÔNG													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/index.php/coc-van-cu-be-tong-du-ung-luc-c59.html">CỌC VÁN CỪ BÊ TÔNG DỰ ỨNG LỰC													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/tam-tuong-be-tong-acotec-c47.html">TẤM TƯỜNG BÊ TÔNG ACOTEC													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/cau-thang-duc-san-c49.html">CẦU THANG ĐÚC SẴN													        													    </a>
													    
													    													    
													</li>
											</ul>

											
										</li><li><a href="/du-an-l7.html">Đối tác <i class="fa fa-angle-down"></i></a>

										
											<ul>

																									<li>
													    													    <a href="/khach-hang-l10.html">Khách hàng													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/nha-cung-cap-l8.html">Nhà cung cấp													        													    </a>
													    
													    													    
													</li>
											</ul>

											
										</li><li><a href="/index.php/vi-deo--a10.html">Thư viện Video</a>

										
										</li><li><a href="/tin-tuc-l2.html">Tin tức <i class="fa fa-angle-down"></i></a>

										
											<ul>

																									<li>
													    													    <a href="/index.php/tin-tuyen-dung--l5.html">Chính sách													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/tin-tuc-l2.html">Tin tức nội bộ													        													    </a>
													    
													    													    
													</li>													<li>
													    													    <a href="/tin-tuc-l2.html">Tin tức chuyên ngành													        													    </a>
													    
													    													    
													</li>
											</ul>

											
										</li><li><a href="/lien-he.html">Liên hệ</a>

										
										</li>
								</ul>
						</div>

					</div>



				</div>

			</div>

		</div>

		<!-- End header -->



		
				<div class="slider_box">

					<!--begin slider-->

				    <div class="owl-carousel owl-theme slide-carousel">

				      	
				      		<div class="item">

				      			<a href=""><img src="images/slide/3333slide-8.jpg" alt="CỐNG HỘP ĐÔI" /></a>

				      			<div>

				      				<h3>CỐNG HỘP ĐÔI</h3>

				      				<p></p>

				      			</div>

				      		</div>

				      		
				      		<div class="item">

				      			<a href=""><img src="images/slide/662slide-4.jpg" alt="ỐNG CỐNG BÊ TÔNG TCVN 9113:2012" /></a>

				      			<div>

				      				<h3>ỐNG CỐNG BÊ TÔNG TCVN 9113:2012</h3>

				      				<p></p>

				      			</div>

				      		</div>

				      		
				      		<div class="item">

				      			<a href=""><img src="images/slide/1210slide-3.jpg" alt="CỐNG BÊ TÔNG ĐÚC SẴN MIỀN BẮC" /></a>

				      			<div>

				      				<h3>CỐNG BÊ TÔNG ĐÚC SẴN MIỀN BẮC</h3>

				      				<p></p>

				      			</div>

				      		</div>

				      		
				      		<div class="item">

				      			<a href=""><img src="images/slide/4624slide-1.jpg" alt="cống hộp chất lượng cao" /></a>

				      			<div>

				      				<h3>cống hộp chất lượng cao</h3>

				      				<p></p>

				      			</div>

				      		</div>

				      		
				    </div>

					<!--end slider-->

					</div>

			    
<!-- Giới thiệu -->
<div class="about_link">
	<div class="container">
		<div class="title">
			<p>Giới thiệu về chúng tôi</p>
		</div>

		<div class="row">
			<div class="col-12 col-md-6 wow fadeInRight left" data-wow-delay="0.3s">
				<div class="name_company">
					<h2>CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC</h2>
				</div>
			</div>

			<div class="col-12 col-md-6 wow fadeInLeft right" data-wow-delay="0.6s">
				<div class="content"><p><span style="font-size:12px"><strong>Với 02 nhà máy sản xuất cống hộp đúc sẵn, hố ga bê tông,.. trên diện tích 50.000m2 tại Hưng Yên và Thái Bình gồm 12 dây chuyền sản xuất và 01 nhà máy sản xuất cống tròn bê tông với đường kính sản phẩm từ D300 đến D2500 bằng công nghệ quay ép tại Sơn Tây, Hà Nội. Công ty Cổ phần Bê tông Phương Bắc tự tin luôn đáp ứng được mọi yêu cầu của khách hàng về cống bê tông và các loại cấu kiện bê tông đúc sẵn khác theo tiêu chuẩn và thiết kế riêng.</strong></span></p>

<p>Sản xuất và cung cấp các loại <a href="https://betongphuongbac.com/index.php/bao-gia-cong-hop-be-tong-duc-san-p53.html">cống bê tông</a> thoát nước, cống tròn, cống hộp, hố ga, tấm đan, hào, rãnh, hộp kỹ thuật, hào cáp điện,...</p>
</div>
			</div>
		</div>
	</div>
</div>

<!-- Liên kết -->
	<div class="service_home">
		<div class="container">
			<div class="row">
									<div class="col-12 col-md-4 item_s">
						<dl>
							<dt><a href="https://betongphuongbac.com/cong-be-tong-c46.html"><img src="images/link/612img_4659.jpg" alt="CỐNG BÊ TÔNG"></a></dt>
							<dd>
								<h3><a href="https://betongphuongbac.com/cong-be-tong-c46.html">CỐNG BÊ TÔNG</a></h3>
								<div> Cống tròn, cống hộp, hào kỹ thuật, hộp cáp điện,hố ga đúc sẵn, rãnh thoát nước, cột điện, cọc bê tông và các cấu kiện bê tông khác…</div>
							</dd>
						</dl>
					</div>
										<div class="col-12 col-md-4 item_s">
						<dl>
							<dt><a href="https://www.betongphuongbac.com/tam-tuong-be-tong-acotec-c47.html"><img src="images/link/2964acotec_3_large.jpg" alt="TẤM TƯỜNG BÊ TÔNG ACOTEC"></a></dt>
							<dd>
								<h3><a href="https://www.betongphuongbac.com/tam-tuong-be-tong-acotec-c47.html">TẤM TƯỜNG BÊ TÔNG ACOTEC</a></h3>
								<div>Thi công các công trình hạ tầng, thi công thoát nước, xây dựng dân dụng, giao thông, các khu công nghiệp cũng như khu đô thị </div>
							</dd>
						</dl>
					</div>
										<div class="col-12 col-md-4 item_s">
						<dl>
							<dt><a href="https://www.betongphuongbac.com/cong-tron-c53.html"><img src="images/link/9297link3.png" alt="KINH DOANH THƯƠNG MẠI, VLXD"></a></dt>
							<dd>
								<h3><a href="https://www.betongphuongbac.com/cong-tron-c53.html">KINH DOANH THƯƠNG MẠI, VLXD</a></h3>
								<div>Cung cấp các sản phẩm phụ trợ cho hệ thống thoát nước như nắp ga chắn rác, ghi chắn rác, lượn sóng, biển báo giao thông…</div>
							</dd>
						</dl>
					</div>
								</div>
		</div>
	</div>
	
	<!-- Sản phẩm -->
	<div class="product">
		<div class="container">
			<div class="title">
				<p><span>Sản phẩm của chúng tôi</span></p>
			</div>

			<div class="brief">
				<p><em><strong>Cung cấp đa dạng các sản phẩm ống cống bê tông, cống hộp, hố ga, tấm tường bê tông acotec</strong></em></p>

<p>​</p>

<p> </p>
			</div>

			<div class="row">
				<div class="owl-carousel owl-theme product-carousel">
			      				      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/6101cong-tron-d2000-(1).png" alt="Công bố giá bán cống bê tông tại thành phố Hà Nội" title="Công bố giá bán cống bê tông tại thành phố Hà Nội">
								</dt>
								<dd>
									<h3>Công bố giá bán cống bê tông tại thành phố Hà Nội</h3>
									<a href="/index.php/cong-bo-gia-ban-cong-be-tong-tai-thanh-pho-ha-noi-p91.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/4600conghopdoi-(2).jpg" alt="Cống hộp đôi H2x(2500x2500)" title="Cống hộp đôi H2x(2500x2500)">
								</dt>
								<dd>
									<h3>Cống hộp đôi H2x(2500x2500)</h3>
									<a href="/index.php/cong-hop-doi-h2x%282500x2500%29-p88.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/5251cong-hop-be-tong-doi-(9).jpg" alt="Cống hộp đôi đúc sẵn theo tiêu chuẩn 9116:2012" title="Cống hộp đôi đúc sẵn theo tiêu chuẩn 9116:2012">
								</dt>
								<dd>
									<h3>Cống hộp đôi đúc sẵn theo tiêu chuẩn 9116:2012</h3>
									<a href="/index.php/cong-hop-doi-duc-san-theo-tieu-chuan-9116%3A2012-p83.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/2951bao-gia-cong-hop-be-tong-duc-san-(1).jpg" alt="BÁO GIÁ CỐNG HỘP CỐNG TRÒN NĂM 2023 TẠI PHÚ THỌ" title="BÁO GIÁ CỐNG HỘP CỐNG TRÒN NĂM 2023 TẠI PHÚ THỌ">
								</dt>
								<dd>
									<h3>BÁO GIÁ CỐNG HỘP CỐNG TRÒN NĂM 2023 TẠI PHÚ THỌ</h3>
									<a href="/index.php/bao-gia-cong-hop-be-tong-cong-tron-nam-2023-tai-phu-tho-p80.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/2418bao-gia-ong-cong-be-tong-duc-san.jpg" alt="BÁO GIÁ CỐNG BÊ TÔNG NĂM 2023 TẠI VĨNH PHÚC " title="BÁO GIÁ CỐNG BÊ TÔNG NĂM 2023 TẠI VĨNH PHÚC ">
								</dt>
								<dd>
									<h3>BÁO GIÁ CỐNG BÊ TÔNG NĂM 2023 TẠI VĨNH PHÚC </h3>
									<a href="/index.php/bao-gia-cong-be-tong-nam-2023-tai-vinh-phuc--p79.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/8951cong-tron-loe-(2).jpg" alt="ỐNG CỐNG BÊ TÔNG ĐÚC SẴN CHẤT LƯỢNG CAO MIỀN BẮC" title="ỐNG CỐNG BÊ TÔNG ĐÚC SẴN CHẤT LƯỢNG CAO MIỀN BẮC">
								</dt>
								<dd>
									<h3>ỐNG CỐNG BÊ TÔNG ĐÚC SẴN CHẤT LƯỢNG CAO MIỀN BẮC</h3>
									<a href="/index.php/cong-be-tong-duc-san-chat-luong-tot-nhat-mien-bac-p71.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/672phu-dien---gach-terrazzo-da-mai.jpg" alt="Gạch lát ngoài trời Terrazzo (lát hè, lát sân vườn, lối đi....)" title="Gạch lát ngoài trời Terrazzo (lát hè, lát sân vườn, lối đi....)">
								</dt>
								<dd>
									<h3>Gạch lát ngoài trời Terrazzo (lát hè, lát sân vườn, lối đi....)</h3>
									<a href="/index.php/gach-lat-ngoai-troi-terrazzo-p67.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/140cong-be-tong-cot-thep-(1).jpg" alt="Cống Tròn Bê Tông đúc sẵn D1200" title="Cống Tròn Bê Tông đúc sẵn D1200">
								</dt>
								<dd>
									<h3>Cống Tròn Bê Tông đúc sẵn D1200</h3>
									<a href="/index.php/cong-tron-be-tong-d1200-p65.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/8180co-hop-doi-be-tong-duc-san-(3).jpg" alt="Cống hộp đôi H2X3000x3000 (3mx3m) đúc sẵn" title="Cống hộp đôi H2X3000x3000 (3mx3m) đúc sẵn">
								</dt>
								<dd>
									<h3>Cống hộp đôi H2X3000x3000 (3mx3m) đúc sẵn</h3>
									<a href="/index.php/cong-hop-doi-h2x3000x3000-%283mx3m%29-duc-san-p56.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/7308-09-concrete-kerbs.jpg" alt="Bó vỉa bê tông cho vỉa hè" title="Bó vỉa bê tông cho vỉa hè">
								</dt>
								<dd>
									<h3>Bó vỉa bê tông cho vỉa hè</h3>
									<a href="/index.php/bo-via-be-tong-cho-via-he-p51.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/7533cong-tron-be-tong-(7).jpg" alt="Cống tròn bê tông cốt thép D1000 " title="Cống tròn bê tông cốt thép D1000 ">
								</dt>
								<dd>
									<h3>Cống tròn bê tông cốt thép D1000 </h3>
									<a href="/index.php/cong-tron-be-tong-cot-thep-d1000--p47.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/9873dsc_2188.jpg" alt=" Ống cống bê tông đúc sẵn D600" title=" Ống cống bê tông đúc sẵn D600">
								</dt>
								<dd>
									<h3> Ống cống bê tông đúc sẵn D600</h3>
									<a href="/index.php/ong-cong-be-tong-duc-san-d600-p19.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/70cong-hop-thoat-nuoc-2_s_1_400_1.jpg" alt="Cống hộp 3000mm x 3000mm (3m x 3m)m" title="Cống hộp 3000mm x 3000mm (3m x 3m)m">
								</dt>
								<dd>
									<h3>Cống hộp 3000mm x 3000mm (3m x 3m)m</h3>
									<a href="/index.php/cong-hop-3000mm-x-3000mm-%283m-x-3m%29-p18.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/7533tuy-nel.jpg" alt=" Tuynel Kỹ thuật (bê tông)" title=" Tuynel Kỹ thuật (bê tông)">
								</dt>
								<dd>
									<h3> Tuynel Kỹ thuật (bê tông)</h3>
									<a href="/index.php/-tuynel-ky-thuat-%28be-tong%29-p9.html"></a>
								</dd>
							</dl>
			      		</div>
			      					      		<div class="item">
				      		<dl>
								<dt>
									<img src="images/attachment/thumb/6059ho-ga-thu-duc-san_s_1_400_1.jpg" alt="Hố ga thu đúc sẵn" title="Hố ga thu đúc sẵn">
								</dt>
								<dd>
									<h3>Hố ga thu đúc sẵn</h3>
									<a href="/index.php/ho-ga-thu-duc-san-p5.html"></a>
								</dd>
							</dl>
			      		</div>
			      					    </div>
			</div>
		</div>
	</div>

	<!-- Dự án -->
	<div class="project">
		<div class="container">

			<div class="title">
				<p><span>Những dự án</span></br> đã hợp tác </p>
			</div>

			<div class="brief">
							</div>

			<div class="row list_project">
									<div class="col-12 col-md-6 item">
						<dl>
		                    <dt>
		                    	<div class="swing">
		                    		<figure><a href="/index.php/du-an/du-an-kcn-so-5-tinh-hung-yen-n53.html"><img src="/images/news/350211011-qh-khu-cong-nghiep-so-5-view-2-1-min-scaled.jpg" alt="Dự án KCN Số 5 tỉnh Hưng Yên" /></a></figure>
		                    	</div>
		                    </dt>
		                    <dd>
		              			<h3><a href="/index.php/du-an/du-an-kcn-so-5-tinh-hung-yen-n53.html">Dự án KCN Số 5 tỉnh Hưng Yên</a>		                    	</h3>
		                    	<p>Khu công nghiệp 5 Hưng Yên có cơ sở hạ tầng được đầu tư kỹ lượng với các khu vực nhà xưởng được phân bố khoảng cách và vị trí phù hợp. Hệ thống giao thông nội khu công nghiệp tiện lợi cùng các trục đường dài 46m, 34m, 23m.

Khu công nghiệp trang bị đầy đủ tiện ích về hệ thống cấp điện để sản xuất, hệ thống cấp nước an toàn theo nhu cầu sử dụng nước của các doanh nghiệp.
Hệ thống xử lý nước thải cũng được quy hoạch an toàn, xử lý theo đúng tiêu chuẩn.

Toàn bộ hệ thống cống thoát nước thải, nước mặt hố ga dược sản xuất và cung cấp bởi Bê Tông Phương Bắc đảm bảo tiêu chuẩn TCVN 9113:2012 và TCVN 9116:2012.
</p>
		                    	<a href="/index.php/du-an/du-an-kcn-so-5-tinh-hung-yen-n53.html"></a>		                    </dd>
		                    <div class="clearfix"></div>
		                </dl>
					</div>

										<div class="col-12 col-md-6 item">
						<dl>
		                    <dt>
		                    	<div class="swing">
		                    		<figure><a href="/index.php/du-an/du-an-khu-dan-cu-do-thi-tai-km3%2C-km4-phuong-hai-yen%2C-thanh-pho-mong-cai-n48.html"><img src="/images/news/7424kdc_km3-km4.jpg" alt="Dự án khu dân cư đô thị tại km3, km4 phường Hải Yên, thành phố Móng Cái" /></a></figure>
		                    	</div>
		                    </dt>
		                    <dd>
		              			<h3><a href="/index.php/du-an/du-an-khu-dan-cu-do-thi-tai-km3%2C-km4-phuong-hai-yen%2C-thanh-pho-mong-cai-n48.html">Dự án khu dân cư đô thị tại km3, km4 phường Hải Yên, thành phố Móng Cái</a>		                    	</h3>
		                    	<p>Dự án khu dân cư đô thị tại km3, km4 phường Hải Yên, thành phố Móng Cái

Chủ đầu tư: Tổng công ty CP VINACONEX



	Địa điểm: Phường Hải Yên, thành phố Móng Cái, tỉnh Quảng Ninh
	Quy mô đầu tư: 438.804 m2
	
		Đất ở: 105.727,5 m2 gồm: 375 căn liên kề, 372 căn shophouse, 35 căn biệt thự
		Đất TMDV: 21.936,3 m2 với mật độ xây dựng 50%, chiều cao tầng từ 11-17 tầng
		Đất giao thông, hạ tầng kỹ thuật, đất khác: 311.141,2 m2
	
	
	Tổng mức đầu tư­:  Khoảng 1.154 tỷ đồng
	Nguồn vốn đầu tư: Vốn tự có, vốn vay, huy động hợp pháp khác của Chủ đầu tư
	Tổng công ty CP Vinaconex trúng đấu giá quyền sử dụng đất ngày 02/02/2021 theo Quyết định số 313/QĐ-UBND của UBDN tỉnh Quảng Ninh. 
	Thời gian thi công: 12 tháng
	Toàn bộ dự án đã hoàn thành việc xây dựng hạ tầng từ tháng 9/2021 


</p>
		                    	<a href="/index.php/du-an/du-an-khu-dan-cu-do-thi-tai-km3%2C-km4-phuong-hai-yen%2C-thanh-pho-mong-cai-n48.html"></a>		                    </dd>
		                    <div class="clearfix"></div>
		                </dl>
					</div>

										<div class="col-12 col-md-6 item">
						<dl>
		                    <dt>
		                    	<div class="swing">
		                    		<figure><a href="/index.php/du-an/du-an-khu-do-thi-phuong-dong-van-don---quang-ninh-n41.html"><img src="/images/news/2598phuong-dong-van-don-1.jpg" alt="DỰ ÁN KHU ĐÔ THỊ PHƯƠNG ĐÔNG VÂN ĐỒN - QUẢNG NINH" /></a></figure>
		                    	</div>
		                    </dt>
		                    <dd>
		              			<h3><a href="/index.php/du-an/du-an-khu-do-thi-phuong-dong-van-don---quang-ninh-n41.html">DỰ ÁN KHU ĐÔ THỊ PHƯƠNG ĐÔNG VÂN ĐỒN - QUẢNG NINH</a>		                    	</h3>
		                    	<p>Khởi nguồn từ “mảnh đất Rồng thiêng” bên vịnh Bái Tử Long kỳ vĩ, Khu đô thị Phương Đông Vân Đồn là sự kết hợp hài hòa giữa cảnh quan thiên nhiên thơ mộng, hữu tình cùng những giá trị lịch sử, văn hóa đậm đà bản sắc tạo nên một quần thể đô thị đẳng cấp, quy mô và sang trọng bậc nhất. Tại Khu đô thị Phương Đông Vân Đồn, chủ đầu tư không chỉ kiến tạo nên một quần thể đô thị hiện đại với đầy đủ tiện ích mà còn mang đến những trải nghiệm sống thú vị trong một thành phố sinh thái, nghỉ dưỡng năng động.
</p>
		                    	<a href="/index.php/du-an/du-an-khu-do-thi-phuong-dong-van-don---quang-ninh-n41.html"></a>		                    </dd>
		                    <div class="clearfix"></div>
		                </dl>
					</div>

										<div class="col-12 col-md-6 item">
						<dl>
		                    <dt>
		                    	<div class="swing">
		                    		<figure><a href="/index.php/du-an/khu-do-thi-ecopark---hung-yen--n11.html"><img src="/images/news/6683nha-giau-ha-noi-‘dich-chuyen’-nguon-dau-tu-ve-phia-dong-nam-175641494117bf32f8605660658d1d98.jpg" alt="Khu đô thị triệu cây xanh Ecopark - Hưng Yên " /></a></figure>
		                    	</div>
		                    </dt>
		                    <dd>
		              			<h3><a href="/index.php/du-an/khu-do-thi-ecopark---hung-yen--n11.html">Khu đô thị triệu cây xanh Ecopark - Hưng Yên </a>		                    	</h3>
		                    	<p>Do Công ty Vihajico làm chủ đầu tư. Dự án đã hoàn thiện giai đoạn 1 và đang triển khai giai đoạn 2. Bê Tông Phương Bắc tự hào cung cấp sản phẩm cống hộp, gối cống, hố ga, và hào kỹ thuật cho dự án.
</p>
		                    	<a href="/index.php/du-an/khu-do-thi-ecopark---hung-yen--n11.html"></a>		                    </dd>
		                    <div class="clearfix"></div>
		                </dl>
					</div>

										
			</div>
		</div>
	</div>


	<div class="partner">
		<div class="container">

			<div class="owl-carousel owl-theme partner-carousel">
		      			      		<div class="item">
		      			<a href="http://vingroup.net/">
		      				<img src="images/partner/4989vin.png" alt="Tập đoàn Vingruop" title="Tập đoàn Vingruop" />
		      			</a>
		      		</div>
		      				      		<div class="item">
		      			<a href="http://www.ecopark.com.vn/">
		      				<img src="images/partner/732ecopark.jpg" alt="Ecopark" title="Ecopark" />
		      			</a>
		      		</div>
		      				      		<div class="item">
		      			<a href="https://www.vietinbank.vn/web/home/vn/index.html">
		      				<img src="images/partner/8570lam-viec-tai-vietinbank-10.png" alt="Vietinbank" title="Vietinbank" />
		      			</a>
		      		</div>
		      				      		<div class="item">
		      			<a href="">
		      				<img src="images/partner/8451logovinaconex.jpg" alt="vinaconex" title="vinaconex" />
		      			</a>
		      		</div>
		      				      		<div class="item">
		      			<a href="https://www.trungnamgroup.com.vn/">
		      				<img src="images/partner/5159trung-nam.png" alt="Công ty Trung Nam" title="Công ty Trung Nam" />
		      			</a>
		      		</div>
		      				      		<div class="item">
		      			<a href="http://www.hud.com.vn/">
		      				<img src="images/partner/709hud-logo-2.jpg" alt="HUD" title="HUD" />
		      			</a>
		      		</div>
		      				      		<div class="item">
		      			<a href="">
		      				<img src="images/partner/7007vietinbank.png" alt="vietin bank" title="vietin bank" />
		      			</a>
		      		</div>
		      				    </div>
		</div>
	</div>
	

	<div class="comment_home">
		<div class="container">
			<div>
				<!--begin slider-->
			    <div class="owl-carousel owl-theme comment-carousel">
			      				      		<div class="item">
				      		<div>
				      			<a><img src="images/comment/8751246x0w.jpg" alt="Mr Hoàng Văn Sơn - PGĐ KD" /></a>
				      			<h3>Mr Hoàng Văn Sơn - PGĐ KD - Phó Giám đốc kinh doanh - 0988563102</h3>
				      			<div>Quý khách có nhu cầu về cống bê tông hãy liên hệ cho chúng tôi để được tư vấn những sản phẩm tốt nhất! </div>
			      			</div>
			      		</div>
			      					      		<div class="item">
				      		<div>
				      			<a><img src="images/comment/6960call.png" alt="Mr Nguyễn Ngọc Hiển" /></a>
				      			<h3>Mr Nguyễn Ngọc Hiển - Kinh doanh Cống bê tông và gioăng cao su - 0985547136</h3>
				      			<div>Cung cấp các loại gioăng cao su cho các mối nối cống tròn, cống hộp</div>
			      			</div>
			      		</div>
			      					      		<div class="item">
				      		<div>
				      			<a><img src="images/comment/2558246x0w.jpg" alt="Đinh Thượng Hải" /></a>
				      			<h3>Đinh Thượng Hải - TP Kinh doanh cống bê tông - 0866622123</h3>
				      			<div>Quý khách quan tâm đến cống bê tông đúc sẵn vui lòng liên hệ với chúng tôi để được tư vấn tốt nhất!</div>
			      			</div>
			      		</div>
			      					    </div>
				<!--end slider-->
			</div>
		</div>
	</div>
	
	<!-- Tin tức mới nhất -->
	<div class="news">
		<div class="container">
			<div class="title">
				<p>Tin tức mới nhất</p>
			</div>

			<div class="row list_news">
								<div class="col-12 col-md-6 big_item">
					<dl>
	                    <dt>
	                    	<div class="swing">
	                    		<figure class="effect-v7"><a href="/index.php/tin-tuc/nhung-cau-hoi-thuong-gap-ve-cong-be-tong-duc-san-n58.html"><img src="/images/news/7512qc-9116-2012-xa-tan-minh-2.jpg" alt="Những câu hỏi thường gặp về cống bê tông đúc sẵn" /></a></figure>
	                    	</div>
	                    </dt>
	                    <dd>
	              			<h3><a href="/index.php/tin-tuc/nhung-cau-hoi-thuong-gap-ve-cong-be-tong-duc-san-n58.html">Những câu hỏi thường gặp về cống bê tông đúc sẵn</a>	                    	</h3>
	                    	<p>Có thể nói, cống bê tông đúc sẵn không chỉ là một sản phẩm xây dựng, mà còn là một giải pháp toàn diện cho mọi công trình hạ tầng. Với những ưu điểm vượt trội về độ bền, tiết kiệm chi phí và thời gian, cống bê tông cốt thép đúc sẵn đã và đang khẳng định vị thế của mình trong ngành xây dựng hiện đại. Chúng ta có thể tự tin rằng, với sự hỗ trợ của những “người hùng thầm lặng” này, các công trình sẽ trở nên kiên cố, bền vững và phục vụ cuộc sống của chúng ta tốt hơn. Hãy là một nhà đầu tư thông thái, lựa chọn sản phẩm chất lượng để đảm bảo sự bền vững cho công trình của bạn!

 
</p>
	                    	<a href="/index.php/tin-tuc/nhung-cau-hoi-thuong-gap-ve-cong-be-tong-duc-san-n58.html">Xem thêm</a>
	                    	<div class="clearfix"></div>
	                    </dd>
	                </dl>

				</div>

				<div class="col-12 col-md-6 right">
												<div class="col-6 item">
								<dl>
				                    <dt>
				                    	<div class="swing">
				                    		<figure class="effect-v7"><a href="/index.php/tin-tuc/nhung-loi-ich-%E2%80%9Cvang%E2%80%9D-khi-lua-chon-cong-be-tong-duc-san-n57.html"><img src="/images/news/6119ong-cong-be-tong-duc-san-d2000.jpg" alt="Những Lợi Ích “Vàng” Khi Lựa Chọn Cống Bê Tông Đúc Sẵn" /></a></figure>
				                    	</div>
				                    </dt>
				                    <dd>
				              			<h3><a href="/index.php/tin-tuc/nhung-loi-ich-%E2%80%9Cvang%E2%80%9D-khi-lua-chon-cong-be-tong-duc-san-n57.html">Những Lợi Ích “Vàng” Khi Lựa Chọn Cống Bê Tông Đúc Sẵn</a>				                    	</h3>
				                    	<a href="/index.php/tin-tuc/nhung-loi-ich-%E2%80%9Cvang%E2%80%9D-khi-lua-chon-cong-be-tong-duc-san-n57.html"></a>				                    </dd>
				                </dl>

							</div>

													<div class="col-6 item">
								<dl>
				                    <dt>
				                    	<div class="swing">
				                    		<figure class="effect-v7"><a href="/index.php/tin-tuc/cong-hop-duc-san%3A-giai-phap-toi-uu-cho-ha-tang-hien-dai-n56.html"><img src="/images/news/6616conghopdoi-(2).jpg" alt="Cống Hộp Đúc Sẵn: Giải Pháp Tối Ưu Cho Hạ Tầng Hiện Đại" /></a></figure>
				                    	</div>
				                    </dt>
				                    <dd>
				              			<h3><a href="/index.php/tin-tuc/cong-hop-duc-san%3A-giai-phap-toi-uu-cho-ha-tang-hien-dai-n56.html">Cống Hộp Đúc Sẵn: Giải Pháp Tối Ưu Cho Hạ Tầng Hiện Đại</a>				                    	</h3>
				                    	<a href="/index.php/tin-tuc/cong-hop-duc-san%3A-giai-phap-toi-uu-cho-ha-tang-hien-dai-n56.html"></a>				                    </dd>
				                </dl>

							</div>

													<div class="col-6 item">
								<dl>
				                    <dt>
				                    	<div class="swing">
				                    		<figure class="effect-v7"><a href="/index.php/tin-tuc/bao-gia-cong-be-tong-duc-san-nam-2025-tai-nam-dinh%2C-thai-binh%2C-ha-nam%2C-hung-yen-n55.html"><img src="/images/news/2776nha-may-cong-(1).jpg" alt="Báo giá cống bê tông đúc sẵn năm 2025 tại Nam Định, Thái Bình, Hà Nam, Hưng Yên" /></a></figure>
				                    	</div>
				                    </dt>
				                    <dd>
				              			<h3><a href="/index.php/tin-tuc/bao-gia-cong-be-tong-duc-san-nam-2025-tai-nam-dinh%2C-thai-binh%2C-ha-nam%2C-hung-yen-n55.html">Báo giá cống bê tông đúc sẵn năm 2025 tại Nam Định, Thái Bình, Hà Nam, Hưng Yên</a>				                    	</h3>
				                    	<a href="/index.php/tin-tuc/bao-gia-cong-be-tong-duc-san-nam-2025-tai-nam-dinh%2C-thai-binh%2C-ha-nam%2C-hung-yen-n55.html"></a>				                    </dd>
				                </dl>

							</div>

													<div class="col-6 item">
								<dl>
				                    <dt>
				                    	<div class="swing">
				                    		<figure class="effect-v7"><a href="/index.php/tin-tuc/san-xuat-cong-tron-tai-nha-may-thai-binh-n54.html"><img src="/images/news/8006cong-tron-d1500-2.jpg" alt="Sản xuất cống tròn tại Nhà máy Thái Bình" /></a></figure>
				                    	</div>
				                    </dt>
				                    <dd>
				              			<h3><a href="/index.php/tin-tuc/san-xuat-cong-tron-tai-nha-may-thai-binh-n54.html">Sản xuất cống tròn tại Nhà máy Thái Bình</a>				                    	</h3>
				                    	<a href="/index.php/tin-tuc/san-xuat-cong-tron-tai-nha-may-thai-binh-n54.html"></a>				                    </dd>
				                </dl>

							</div>

										</div>
					
			</div>

		</div>
	</div>



		<div class="footer">

			<div class="container">

				<div class="row">

					<div class="col-12 col-md-3 footer_item info_footer">

						<a href="/index.php"><img src="images/contact/4174logo_bt.png" alt="CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC" /></a>

						<div class="social">

							<a href="" target="_blank"><i class="fa fa-twitter"></i></a>

							<a href="https://www.facebook.com/phuongbac.betong" target="_blank"><i class="fa fa-facebook"></i></a>

							<a href="" target="_blank"><i class="fa fa-google-plus"></i></a>

						</div>

					</div>

					<div class="col-12 col-md-5 footer_item contact_footer">

						<p>CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC</p>

						<div>

							<p class="address">Địa chỉ: Thôn Tổ Hỏa - Xã Yên Mỹ, Tỉnh Hưng Yên - MSDN : 0900988752 cấp ngày 28/03/2016 tại Hưng Yên</p>

							<p class="phone">Điện thoại: 0947881181</p>

							<p class="email">Email: betongphuongbac@gmail.com</p>

							<p class="web">Website: https://betongphuongbac.com</p>

						</div>

					</div>



					
								<div class="col-12 col-md-2 footer_item menu_footer">

									<p>Dịch vụ</p>

									<div>

										<ul>

											<li><a href="#">Vận tải</a></li><li><a href="#">Thi công lắp đặt, hoàn thiện tấm tường</a></li><li><a href="#">Kinh doanh thương mại, VLXD</a></li>
										</ul>

									</div>

								</div>

								
								<div class="col-12 col-md-2 footer_item menu_footer">

									<p>Sản phẩm</p>

									<div>

										<ul>

											<li><a href="#">Hố ga bê tông</a></li><li><a href="#">Cống hộp bê tông</a></li><li><a href="#">Hố ga đúc sẵn</a></li><li><a href="#">Rãnh thoát nước</a></li>
										</ul>

									</div>

								</div>

								


				</div>

			</div>

		</div>

		<!-- End footer -->



		<div class="bottom_page">

			<div class="container">
				<div class="row">

					<div class="col-9 item wow bounceInLeft">
						<p>BẢN QUYỀN THUỘC VỀ CÔNG TY CỔ PHẦN BÊ TÔNG PHƯƠNG BẮC</p>
					</div>

					<div class="col-3 item item2">
					    <div class="go-top">
					    <a href="#" ><i class="fa fa-arrow-up"></i></a>
					    </div>
					        <a href="http://online.gov.vn/HomePage/CustomWebsiteDisplay.aspx?DocId=57677" class="bct" target="_blank"><img src="images/contact/2171da-thong-bao-bct.png" alt="Thông báo Bộ Công Thương" /></a>
						
					</div>
					<div class="clearfix"></div>

				</div>

			</div>

		</div>



	</div>

	<!-- End wrapper -->


    <div class="zalo-now hidden-md hidden-lg">
    	<div class="call-now">
    		<div class="circle" style="border-color:#43A1F3;"></div>
    		<div class="circle-fill" style="background-color:#43A1F3;"></div>
    		<a href="https://zalo.me/0947881181" target="_blank">
    			<div class="img-circle circle-shake" style="background-color:#43A1F3;opacity:0.9;background-image: url('../css/images/zalo-chat.png');background-size: 35px;"></div>
    		</a>
    	</div>
    </div>


	<div class="phone-call-now hidden-md hidden-lg">

		<div class="call-now">

			<div class="circle" style="border-color:#ff0307;"></div>

			<div class="circle-fill" style="background-color:#ff0307;"></div>

			<a href="tel:0947881181">

			<div class="img-circle circle-shake" style="background-color:#ff0307;opacity:0.9;background-image: url('https://tools.vinaweb.vn/images/widget/phone/phone5.png');"></div>

			</a>

		</div>

	</div>

	

</body>

</html>